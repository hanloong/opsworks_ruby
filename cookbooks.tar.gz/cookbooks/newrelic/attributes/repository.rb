#
# Cookbook Name:: newrelic
# Attributes:: repository
#
# Copyright 2012-2014, Escape Studios
#

default['newrelic']['repository']['repository_key'] = '548C16BF'
default['newrelic']['repository']['repository_action'] = :install
