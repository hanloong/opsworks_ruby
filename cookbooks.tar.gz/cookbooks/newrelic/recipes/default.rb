#
# Cookbook Name:: newrelic
# Recipe:: default
#
# Copyright 2012-2014, Escape Studios
#

include_recipe 'newrelic::server_monitor_agent'
